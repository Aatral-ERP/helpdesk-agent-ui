export class Contact {
    city: any = '';
    country: any = '';
    emailId: any = '';
    firstName: any = '';
    id: any = 0;
    instituteId: any = '';
    isBlocked: any;
    lastName: any = '';
    password: any = null;
    phone: any = '';
    state: any = '';
    street1: any = '';
    street2: any = '';
    zipcode: any = '';
}