
// export class Institute
// {
//     public id : any;
//     public instituteId : any;
//     public instituteName : any;
//     public instituteType: any; 
//     public phone : any;  
//     public emailId : any;    
//     public street1 : any;
//     public street2 : any;
//     public city : any;
//     public state : any;
//     public country :any;
//     public zipcode :any;
//     public alternateEmailId : any;
//     public alternatePhone : any;
//     public serviceUnder:any;
   
// }