export class Message{
    public id :any;
    public chatId :any;
    public memberCode :any;
    public adminMemberCode :any;
    public message :any;
    public messageBy :any;
    public isDeleted :any;
    public isRead :any;
    public messageDatetime :any;
    public messageByName : any;
    public adminMemberName : any;

    public userMailId : any;
    public agentMailId : any;
    public agentName : any;
    
    
}